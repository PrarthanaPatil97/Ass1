﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace PrarthanaLampShades.Models
{
    public class LampShades
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Shape { get; set; }
   
        public string Color { get; set; }
        public decimal Price { get; set; }
    }
}
