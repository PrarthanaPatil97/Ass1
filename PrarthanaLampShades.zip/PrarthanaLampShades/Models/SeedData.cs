﻿
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using PrarthanaLampShades.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PrarthanaLampShades.Models
{
    public class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new PrarthanaLampShadesContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<PrarthanaLampShadesContext>>()))
            {
                // Look for any lampshades.
                if (context.LampShades.Any())
                {
                    return;   // DB has been seeded
                }

                context.LampShades.AddRange(
                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "round",
                        Price = 7.99M,
                    },

                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "Square",
                        Price = 7.99M,
                    },

                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "Triangle",
                        Price = 7.99M,
                    },

                    new LampShades
                    {
                        Title = "When Harry Met Sally",
                        Color = "Romantic Comedy",
                        Shape = "oval",
                        Price = 7.99M,
                    }
                );
                context.SaveChanges();
            }
        }
    }
}

